# CHANGELOG.md

## [4.0.0] - 2024-09-11

Redesign the entire template

## [3.3.0] - 2023-12-08

Update to Next.js 14
Update dependencies

## [3.2.2] - 2023-10-04

Update Twitter icon
Update dependencies

## [3.2.0] - 2023-05-31

Update dependencies and fix some issues

## [3.1.0] - 2023-05-07

Modal video improvements

## [3.0.0] - 2023-04-12

Conversion to Next.js

## [2.0.3] - 2023-03-28

Fix video

## [2.0.2] - 2023-03-28

Add self-hosted video

## [2.0.1] - 2023-02-16

Remove header links

## [2.0.0] - 2023-02-16

Replace Cruip CSS with Tailwind CSS

## [1.0.0] - 2020-04-07

First release
